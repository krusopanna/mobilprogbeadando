package com.example.garageapp

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface CarDatabaseActions {
    @Query("SELECT * FROM car_table")
    fun getAllCars(): List<Car>

    @Insert
    fun insertCar(car: Car)

    @Delete
    fun deleteCar(car: Car)

    @Query("DELETE FROM car_table WHERE id = :carId")
    fun deleteCarById(carId: Long)

    @Update
    fun updateCar(car: Car)
}