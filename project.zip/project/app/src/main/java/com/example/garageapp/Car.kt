package com.example.garageapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "car_table")
data class Car(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    val brand: String,
    val model: String,
    val year: Int,
    val hasRegistration: Boolean
)