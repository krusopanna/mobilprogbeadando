package com.example.garageapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        database = AppDatabase.getInstance(this)

        val inputBrand = findViewById<EditText>(R.id.inputBrand)
        val inputModel = findViewById<EditText>(R.id.inputModel)
        val inputYear = findViewById<EditText>(R.id.inputYear)
        val checkBox = findViewById<CheckBox>(R.id.checkBox)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val listButton = findViewById<Button>(R.id.listButton)
        val resultTextView = findViewById<TextView>(R.id.resultTextView)

        val deletePanel = findViewById<LinearLayout>(R.id.deletePanel)
        val inputDeleteId = findViewById<EditText>(R.id.inputDeleteId)
        val deleteButton = findViewById<Button>(R.id.deleteButton)
        val updateButton = findViewById<Button>(R.id.updateButton)

        saveButton.setOnClickListener {
            val brandText = inputBrand.text.toString()
            val modelText = inputModel.text.toString()
            val yearText = inputYear.text.toString()
            val hasReg = checkBox.isChecked

            if (brandText.isNotEmpty() && modelText.isNotEmpty() && yearText.isNotEmpty()) {
                val newCar = Car(brand = brandText, model = modelText, year = yearText.toInt(), hasRegistration = hasReg)
                database.carDatabaseActions().insertCar(newCar)

                inputBrand.text.clear()
                inputModel.text.clear()
                inputYear.text.clear()

                deletePanel.visibility = View.GONE

                Toast.makeText(this, "Verda bekerült a garázsba!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Tölts ki mindent!", Toast.LENGTH_SHORT).show()
            }
        }

        listButton.setOnClickListener {
            val carList = database.carDatabaseActions().getAllCars()

            if (carList.isEmpty()) {
                resultTextView.text = "A garázs jelenleg üres."
                deletePanel.visibility = View.GONE
            } else {
                val stringBuilder = StringBuilder()
                for (car in carList) {
                    val papirSzoveg = if (car.hasRegistration) "✅ Van évényes forgalmi" else "❌ Nincs érvényes forgalmi"
                    stringBuilder.append("ID: ${car.id} | ${car.brand} ${car.model} (${car.year})\n")
                    stringBuilder.append("$papirSzoveg\n")
                    stringBuilder.append("--------------------\n")
                }
                resultTextView.text = stringBuilder.toString()

                deletePanel.visibility = View.VISIBLE
            }
        }

        deleteButton.setOnClickListener {
            val idText = inputDeleteId.text.toString()

            if (idText.isNotEmpty()) {
                val idToDelete = idText.toLong()
                database.carDatabaseActions().deleteCarById(idToDelete)

                Toast.makeText(this, "Kivágtuk a vasat a telepről!", Toast.LENGTH_LONG).show()
                inputDeleteId.text.clear()

                listButton.performClick()
            } else {
                Toast.makeText(this, "Írj be egy ID számot!", Toast.LENGTH_SHORT).show()
            }
        }

        updateButton.setOnClickListener {
            val idText = inputDeleteId.text.toString()
            val brandText = inputBrand.text.toString()
            val modelText = inputModel.text.toString()
            val yearText = inputYear.text.toString()
            val hasReg = checkBox.isChecked

            if (idText.isNotEmpty() && brandText.isNotEmpty() && modelText.isNotEmpty()) {
                val idToUpdate = idText.toLong()

                val updatedCar = Car(id = idToUpdate, brand = brandText, model = modelText, year = yearText.toInt(), hasRegistration = hasReg)

                database.carDatabaseActions().updateCar(updatedCar)

                Toast.makeText(this, "Adatok javítva!", Toast.LENGTH_SHORT).show()

                inputDeleteId.text.clear()
                inputBrand.text.clear()
                inputModel.text.clear()
                inputYear.text.clear()
                checkBox.isChecked = false

                listButton.performClick()
            } else {
                Toast.makeText(this, "ID alulra, új adatok felülre!", Toast.LENGTH_LONG).show()
            }
        }
    }
}